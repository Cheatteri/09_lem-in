make
./../lem-in < right_maps/1 #short
#start-ykkonen-nelonen-end
echo  -e "\033[33;7mpress enter\033[0m"
read next
clear
./../lem-in < right_maps/2 #loop
#start-ykkonen-nelonen-end
#start-ykkonen-kuutonen-viisi-end
echo  -e "\033[33;7mpress enter\033[0m"
read next
clear
./../lem-in < right_maps/3 #longer_loop
#start-ykkonen-nelonen-kasi-ysi-kymppi-end
#start-ykkonen-kuutonen-viisi-end
echo  -e "\033[33;7mpress enter\033[0m"
read next
clear
./../lem-in < right_maps/4 #1k rooms
echo  -e "\033[33;7mpress enter\033[0m"
read next
clear
./../lem-in < right_maps/5 #10k rooms